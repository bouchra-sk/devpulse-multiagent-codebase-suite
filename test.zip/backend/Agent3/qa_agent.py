"""
Agent 3 : Codebase Q&A Copilot Agent
-------------------------------------
Répond aux questions du développeur en utilisant
le code du projet indexé par l'Agent 1.
"""

from backend.Agent1.rag import query_index
from backend.Agent2.llm_client import call_llm


SYSTEM_PROMPT = """
Tu es un assistant expert en compréhension de code.

Ton rôle est d'aider un développeur à comprendre
un projet logiciel qu'il découvre.

Tu dois répondre uniquement à partir des extraits
de code fournis dans le contexte.

Règles :
- Ne pas inventer de fichiers, fonctions ou comportements.
- Si l'information n'est pas présente dans les extraits,
  indique clairement que tu ne peux pas la déterminer.
- Explique les choses simplement et précisément.
- Cite les fichiers pertinents dans ta réponse lorsque
  l'information est disponible.
- Réponds en français.
"""


def answer_question(
    project_id: str,
    question: str,
    n_results: int = 5
) -> dict:
    """
    Répond à une question du développeur en utilisant le RAG de l'Agent 1.

    Retourne :
    {
        "answer": str,           # réponse en langage naturel
        "mocked": bool,          # True si pas de vrai LLM connecté
        "sources": [             # extraits utilisés, pour affichage structuré
            {"file": str, "snippet": str}, ...
        ]
    }
    """

    # 1. Recherche dans ChromaDB
    matches = query_index(project_id, question, n_results=n_results)

    # 2. Aucun résultat trouvé — pas besoin d'appeler le LLM
    if not matches:
        return {
            "answer": (
                "Je n'ai trouvé aucun extrait pertinent "
                "dans le code indexé pour répondre à cette question."
            ),
            "mocked": False,
            "sources": [],
        }

    # 3. Préparer les sources pour l'affichage (extrait raccourci, lisible)
    sources = [
        {
            "file": match.get("metadata", {}).get("file_path", "Fichier inconnu"),
            "snippet": match.get("text", "")[:500],
        }
        for match in matches
    ]

    # 4. Préparer le contexte complet pour le LLM (texte entier, pas raccourci)
    context_blocks = [
        f"\n--- Fichier : {match.get('metadata', {}).get('file_path', 'Fichier inconnu')} ---\n\n"
        f"{match.get('text', '')}\n"
        for match in matches
    ]
    context = "\n".join(context_blocks)

    user_prompt = f"""
Voici les extraits du projet trouvés par le système RAG :

{context}

Question du développeur :

{question}

Réponds à la question uniquement à partir
des extraits fournis.

Indique les fichiers concernés lorsque c'est pertinent.
"""

    # 5. Envoyer le contexte + la question à IBM Bob 2.0
    result = call_llm(SYSTEM_PROMPT, user_prompt)

    # 6. En mode simulation : pas de wall of text, juste un message court +
    #    les extraits structurés (le frontend les affichera proprement).
    if result["mocked"]:
        return {
            "answer": (
                f"🔧 Mode simulation — {len(sources)} extrait(s) pertinent(s) "
                "trouvé(s) pour ta question (affichés ci-dessous). Une vraie "
                "synthèse arrivera une fois IBM Bob 2.0 connecté."
            ),
            "mocked": True,
            "sources": sources,
        }

    # 7. Réponse réelle du LLM
    return {"answer": result["content"], "mocked": False, "sources": sources}